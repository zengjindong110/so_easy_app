import requests


class ReQu(object):
    def __init__(self):
        pass

    def request(self, method, url, request_data=dict()):

        if method.upper() in ["POST", "PUT"]:
            respond = requests.request(method, url=url, data=request_data)
            # print(respond.text)
            return respond.text
        elif method.upper() in ["GET", "DELETE"]:
            # print(data)
            respond = requests.request(method, url=url, params=request_data)
            # print(respond.text)
            return respond.text

        else:
            return "请求方式不存在"


if __name__ == '__main__':
    r = ReQu()
    data = {}
    r.request("get", "https://www.runoob.com/python3/python3-upper-lower.html", request_data=data)
{'method': 'get', 'url': 'http://www.baidu.com'}