import json
import os
from abc import ABC

import pymysql
from tornado.web import RequestHandler
from tornado import log, options
from app.pack.link_mysql import execut
from app.pack.deal_whit_request import ReQu


# options.log_file_prefix = os.path.join(os.path.dirname(__file__), 'logs/tornado_main.log')
def change_data(d):
    for i in list(d.keys()):
        try:
            d[i] = eval(d[i])
        except Exception:
            pass
    print(d)
    return d


def save_data(post_data="", respond="", url="", method=""):
    try:
        if method != "":
            # print(post_data, respond, url, method)
            sql = """INSERT INTO `post_data`(`post_data`, `respond`, `url`, `method`) VALUES ('{}','{}','{}','{}')""".format(
                str(pymysql.escape_string(str(post_data))), str(pymysql.escape_string(respond)), str(url), str(method))
            execut(sql)
    except EOFError:
        return "参数格式异常"


def use_data():
    select_data = """SELECT * FROM `post_data`"""
    #
    my_data = execut(select_data)
    print(my_data)


class PostData(RequestHandler):

    def set_default_headers(self):
        self.set_header("host", "BigGe")
        self.set_header("careful", "www.baidu.com")

    def get(self, *args, **kwargs):
        xx = self.get_body_arguments("User-Agent", strip=True)
        head = self.request.headers
        self.render("index.html")

    def post(self, *args, **kwargs):
        # 接受参数
        post_data = self.request.body_arguments
        post_data = {x: post_data.get(x)[0].decode(
            "utf-8") for x in post_data.keys()}
        if not post_data:
            post_data = self.request.body.decode('utf-8')
            post_data = json.loads(post_data)

        print(post_data)
        method = post_data.pop("method")
        url = post_data.pop("url")
        post_data = change_data(post_data)
        r = ReQu()
        respond = r.request(method=method, url=url, request_data=post_data)
        # print(respond)
        self.write("<xmp>{}</xmp>".format(respond))
        try:
            save_data(post_data, respond, url, method)
        except TypeError:
            return "数据库异常"
