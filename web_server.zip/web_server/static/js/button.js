
// var all_form =  document.getElementsByClassName("form")
all_form[0].onsubmit = function() {

	return false;
}


try {
	all_form[1].onsubmit = function() {
	// alert(all_form.length)
		var gateway = document.getElementById('gateway');
		var url_value = all_form[1].getElementsByTagName("input");

		if(gateway.value==url_value[1].value.slice(0,gateway.value.length)){

		}
		else {
			url_value[1].value=gateway.value+url_value[1].value
		}
	}
} catch (e) {

} finally {

}


all_form[2].onsubmit = function() {

	var gateway = document.getElementById('gateway');
	var url_value = all_form[2].getElementsByTagName("input");

	if(gateway.value==url_value[1].value.slice(0,gateway.value.length)){

	}
	else {
		url_value[1].value=gateway.value+url_value[1].value
	}
}

all_form[3].onsubmit = function() {

	var gateway = document.getElementById('gateway');
	var url_value = all_form[3].getElementsByTagName("input");

	if(gateway.value==url_value[1].value.slice(0,gateway.value.length)){

	}
	else {
		url_value[1].value=gateway.value+url_value[1].value
	}
}

all_form[4].onsubmit = function() {

	var gateway = document.getElementById('gateway');
	var url_value = all_form[4].getElementsByTagName("input");

	if(gateway.value==url_value[1].value.slice(0,gateway.value.length)){

	}
	else {
		url_value[1].value=gateway.value+url_value[1].value
	}
}

all_form[5].onsubmit = function() {

	var gateway = document.getElementById('gateway');
	var url_value = all_form[5].getElementsByTagName("input");

	if(gateway.value==url_value[1].value.slice(0,gateway.value.length)){

	}
	else {
		url_value[1].value=gateway.value+url_value[1].value
	}
}
all_form[6].onsubmit = function() {

	var gateway = document.getElementById('gateway');
	var url_value = all_form[6].getElementsByTagName("input");

	if(gateway.value==url_value[1].value.slice(0,gateway.value.length)){

	}
	else {
		url_value[1].value=gateway.value+url_value[1].value
	}
}
all_form[7].onsubmit = function() {

	var gateway = document.getElementById('gateway');
	var url_value = all_form[7].getElementsByTagName("input");

	if(gateway.value==url_value[1].value.slice(0,gateway.value.length)){

	}
	else {
		url_value[1].value=gateway.value+url_value[1].value
	}
}
all_form[8].onsubmit = function() {

	var gateway = document.getElementById('gateway');
	var url_value = all_form[8].getElementsByTagName("input");

	if(gateway.value==url_value[1].value.slice(0,gateway.value.length)){

	}
	else {
		url_value[1].value=gateway.value+url_value[1].value
	}
}
all_form[9].onsubmit = function() {
alert(all_form.length)
	var gateway = document.getElementById('gateway');
	var url_value = all_form[9].getElementsByTagName("input");

	if(gateway.value==url_value[1].value.slice(0,gateway.value.length)){

	}
	else {
		url_value[1].value=gateway.value+url_value[1].value
	}
}




try {
  all_form[10].onsubmit = function() {

  	var gateway = document.getElementById('gateway');
  	var url_value = all_form[10].getElementsByTagName("input");

  	if(gateway.value==url_value[1].value.slice(0,gateway.value.length)){

  	}
  	else {
  		url_value[1].value=gateway.value+url_value[1].value
  	}
  }
}
catch(err) {

}

try {
  all_form[11].onsubmit = function() {

  	var gateway = document.getElementById('gateway');
  	var url_value = all_form[11].getElementsByTagName("input");

  	if(gateway.value==url_value[1].value.slice(0,gateway.value.length)){

  	}
  	else {
  		url_value[1].value=gateway.value+url_value[1].value
  	}
  }
}
catch(err) {

}
try {
  all_form[12].onsubmit = function() {

  	var gateway = document.getElementById('gateway');
  	var url_value = all_form[12].getElementsByTagName("input");

  	if(gateway.value==url_value[1].value.slice(0,gateway.value.length)){

  	}
  	else {
  		url_value[1].value=gateway.value+url_value[1].value
  	}
  }
}
catch(err) {

}

try {
  all_form[13].onsubmit = function() {

  	var gateway = document.getElementById('gateway');
  	var url_value = all_form[13].getElementsByTagName("input");

  	if(gateway.value==url_value[1].value.slice(0,gateway.value.length)){

  	}
  	else {
  		url_value[1].value=gateway.value+url_value[1].value
  	}
  }
}
catch(err) {

}
try {
  all_form[14].onsubmit = function() {

  	var gateway = document.getElementById('gateway');
  	var url_value = all_form[14].getElementsByTagName("input");

  	if(gateway.value==url_value[1].value.slice(0,gateway.value.length)){

  	}
  	else {
  		url_value[1].value=gateway.value+url_value[1].value
  	}
  }
}
catch(err) {

}

try {
  all_form[15].onsubmit = function() {

  	var gateway = document.getElementById('gateway');
  	var url_value = all_form[15].getElementsByTagName("input");

  	if(gateway.value==url_value[1].value.slice(0,gateway.value.length)){

  	}
  	else {
  		url_value[1].value=gateway.value+url_value[1].value
  	}
  }
}
catch(err) {

}

try {
  all_form[16].onsubmit = function() {

  	var gateway = document.getElementById('gateway');
  	var url_value = all_form[16].getElementsByTagName("input");

  	if(gateway.value==url_value[1].value.slice(0,gateway.value.length)){

  	}
  	else {
  		url_value[1].value=gateway.value+url_value[1].value
  	}
  }
}
catch(err) {

}

try {
  all_form[17].onsubmit = function() {

  	var gateway = document.getElementById('gateway');
  	var url_value = all_form[17].getElementsByTagName("input");

  	if(gateway.value==url_value[1].value.slice(0,gateway.value.length)){

  	}
  	else {
  		url_value[1].value=gateway.value+url_value[1].value
  	}
  }
}
catch(err) {

}

try {
  all_form[19].onsubmit = function() {

  	var gateway = document.getElementById('gateway');
  	var url_value = all_form[19].getElementsByTagName("input");

  	if(gateway.value==url_value[1].value.slice(0,gateway.value.length)){

  	}
  	else {
  		url_value[1].value=gateway.value+url_value[1].value
  	}
  }
}
catch(err) {

}

try {
  all_form[20].onsubmit = function() {

  	var gateway = document.getElementById('gateway');
  	var url_value = all_form[20].getElementsByTagName("input");

  	if(gateway.value==url_value[1].value.slice(0,gateway.value.length)){

  	}
  	else {
  		url_value[1].value=gateway.value+url_value[1].value
  	}
  }
}
catch(err) {

}

try {
  all_form[21].onsubmit = function() {

  	var gateway = document.getElementById('gateway');
  	var url_value = all_form[21].getElementsByTagName("input");

  	if(gateway.value==url_value[1].value.slice(0,gateway.value.length)){

  	}
  	else {
  		url_value[1].value=gateway.value+url_value[1].value
  	}
  }
}
catch(err) {

}

try {
  all_form[22].onsubmit = function() {

  	var gateway = document.getElementById('gateway');
  	var url_value = all_form[22].getElementsByTagName("input");

  	if(gateway.value==url_value[1].value.slice(0,gateway.value.length)){

  	}
  	else {
  		url_value[1].value=gateway.value+url_value[1].value
  	}
  }
}
catch(err) {

}

try {
  all_form[23].onsubmit = function() {

  	var gateway = document.getElementById('gateway');
  	var url_value = all_form[23].getElementsByTagName("input");

  	if(gateway.value==url_value[1].value.slice(0,gateway.value.length)){

  	}
  	else {
  		url_value[1].value=gateway.value+url_value[1].value
  	}
  }
}
catch(err) {

}

try {
  all_form[24].onsubmit = function() {

  	var gateway = document.getElementById('gateway');
  	var url_value = all_form[24].getElementsByTagName("input");

  	if(gateway.value==url_value[1].value.slice(0,gateway.value.length)){

  	}
  	else {
  		url_value[1].value=gateway.value+url_value[1].value
  	}
  }
}
catch(err) {

}

try {
  all_form[25].onsubmit = function() {

  	var gateway = document.getElementById('gateway');
  	var url_value = all_form[25].getElementsByTagName("input");

  	if(gateway.value==url_value[1].value.slice(0,gateway.value.length)){

  	}
  	else {
  		url_value[1].value=gateway.value+url_value[1].value
  	}
  }
}
catch(err) {

}

try {
  all_form[26].onsubmit = function() {

  	var gateway = document.getElementById('gateway');
  	var url_value = all_form[26].getElementsByTagName("input");

  	if(gateway.value==url_value[1].value.slice(0,gateway.value.length)){

  	}
  	else {
  		url_value[1].value=gateway.value+url_value[1].value
  	}
  }
}
catch(err) {

}

try {
  all_form[27].onsubmit = function() {

  	var gateway = document.getElementById('gateway');
  	var url_value = all_form[27].getElementsByTagName("input");

  	if(gateway.value==url_value[1].value.slice(0,gateway.value.length)){

  	}
  	else {
  		url_value[1].value=gateway.value+url_value[1].value
  	}
  }
}
catch(err) {

}
try {
  all_form[28].onsubmit = function() {

  	var gateway = document.getElementById('gateway');
  	var url_value = all_form[28].getElementsByTagName("input");

  	if(gateway.value==url_value[1].value.slice(0,gateway.value.length)){

  	}
  	else {
  		url_value[1].value=gateway.value+url_value[1].value
  	}
  }
}
catch(err) {

}try {
  all_form[29].onsubmit = function() {

  	var gateway = document.getElementById('gateway');
  	var url_value = all_form[29].getElementsByTagName("input");

  	if(gateway.value==url_value[1].value.slice(0,gateway.value.length)){

  	}
  	else {
  		url_value[1].value=gateway.value+url_value[1].value
  	}
  }
}
catch(err) {

}try {
  all_form[30].onsubmit = function() {

  	var gateway = document.getElementById('gateway');
  	var url_value = all_form[30].getElementsByTagName("input");

  	if(gateway.value==url_value[1].value.slice(0,gateway.value.length)){

  	}
  	else {
  		url_value[1].value=gateway.value+url_value[1].value
  	}
  }
}
catch(err) {

}
