function Table(mytype,n){
			var mytype,TemO=document.getElementsByClassName("addtr");
			// alert(TemO.length);
			var newInput = document.createElement("input");
			var table = document.createElement("table");
			table.setAttribute('border','1');
			var addtr = document.createElement('tr');

			newInput.type=mytype;
			newInput.name="input";
			TemO[n].appendChild(newInput);

}

function add_submit(){
		// 获取所有的form
	var get_form=document.getElementsByClassName("form");

	for (i=0;i<get_form.length;i++){
		get_form[i].target="iframe"+i;
		//获取每个form所有的input
		var inputs =get_form[i].getElementsByTagName("input");
		// 获取第一行所有的的input
		var input_value =get_form[0].getElementsByTagName("input");
		//加添submit元素

		inputs[inputs.length-1].type="submit"
		input_value[0].value="method";
		input_value[1].value="url";
		//删除第一个提交  待研究
		input_value[input_value.length-1]
		//删除input元素name属性
		inputs[inputs.length-1].removeAttribute("name");
		//给每个input标签添加属性

		for (x=0;x<=inputs.length-2;x++){
			inputs[x].name=input_value[x].value;
			inputs[x].type="text";
		}
	}
window.all_form =  document.getElementsByClassName("form");
reloadAbleJSFn('loadjs','../static/js/button.js');
// add_ifarm();

}


function AddTable(mytype){
	//添加一列table
	var TemO=document.getElementsByClassName("form");

	for (i=0;i<TemO.length;i++)
	{

		Table(mytype,i);
		// add_submit();
	}

}

function Form(){
	//生成form
				var mytype,TemO=document.getElementById("add_form");
				var newInput = document.createElement("form");
				var table = document.createElement("table");
				var addtr = document.createElement("tr");
				addtr.className="addtr";
				table.className = "table";
				newInput.method="post";

				// alert(111)
				// newInput.onsubmit="PostData()";
				// alert(newInput.onsubmit)

				newInput.className ="form";
				newInput.action = "http://127.0.0.1:8000/PostData"
				newInput.id ="form";
				table.appendChild(addtr)
				newInput.appendChild(table);
				TemO.appendChild(newInput);
				}

//  i == form的数量
function form_num(n){
	for (i=0; i<n; i++){
		Form();

	}
}
form_num(10);

//  i == table的数量
function table_num(m){
	for (n=0; n<m; n++){
		AddTable("text");

	}
}

table_num(10);

function AddForm(){
	//添加form
	//获取所有的form标签
	var table_len = document.getElementsByClassName("form");
	// alert(table_len.length)
	var inputs = table_len[0].getElementsByTagName("input");

	var table_len_num = table_len.length;
	Form();
	for (i=0; i< inputs.length; i++){
		// alert(i)
		table_len[i].target="iframe"+i;
		Table("text",table_len_num);
	}
}
add_submit();

function creat_ifarm(){
	var table_len = document.getElementsByClassName("form").length;
	var add_ifarm = document.getElementById('respond_data');
	for (i=0; i<table_len;i++ ){

		var ifram = document.createElement("iframe")
		ifram.name= "iframe"+i;
		ifram.className="ifarm"
		add_ifarm.appendChild(ifram);
	}
}

creat_ifarm();

function add_ifarm(){
	var table_len = document.getElementsByClassName("form").length;
	var add_ifarm = document.getElementById('respond_data');

	var ifarm_length = document.getElementsByClassName('ifarm').length;

	if(ifarm_length<table_len){
		for (i=ifarm_length; i<table_len;i++ ){

			var ifram = document.createElement("iframe")
			ifram.name= "iframe"+i;
			ifram.className="ifarm"
			add_ifarm.appendChild(ifram);

		}
	}
}

function reloadAbleJSFn(id,newJS)
//重新加载button.js

{
    var oldjs = null;
    var t = null;
    var oldjs = document.getElementById(id);
    if(oldjs) oldjs.parentNode.removeChild(oldjs);
    var scriptObj = document.createElement("script");
		// alert(newJS)
    scriptObj.src = newJS;
    scriptObj.type = "text/javascript";
    scriptObj.id = id;
    document.getElementsByTagName("head")[0].appendChild(scriptObj);
}
