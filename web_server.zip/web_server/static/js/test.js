
    function sub() {  
        $.ajax({  
                cache: true,  
                type: "POST",  
                url:"Servlet",  
                data:$('#formId').serialize(),// 你的formid  
                async: false,  
                error: function(request) {  
                    alert("Connection error:"+request.error);  
                },  
                success: function(data) {  
                    alert("SUCCESS!");  
                }  
            });  
    }  
