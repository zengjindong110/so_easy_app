import json
import os
from time import sleep
from app.app import *

import requests
from tornado import options
from tornado.httpserver import HTTPServer
from tornado.ioloop import IOLoop
from tornado.options import define, parse_config_file
from tornado.web import Application, RequestHandler
# from app.pack.link_mysql import LinkMysql

define("port", type=int, default=8000)
parse_config_file("./config")


def run():
    app = Application(handlers=[
        ("/PostData", PostData)],
        template_path=os.path.join(os.path.dirname(__file__), "templates"),
        static_path=os.path.join(os.path.dirname(__file__), "static")
    )
    server = HTTPServer(app)
    server.listen(options.options.port)
    IOLoop.current().start()


if __name__ == '__main__':
    run()
